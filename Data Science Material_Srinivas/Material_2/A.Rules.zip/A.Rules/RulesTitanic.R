#Association Rules

Titanic<-read.csv("C:\\1.Srinivas\\Material\\Excelr\\1.Course Material\\Week 3\\A.Rules\\Titanic.csv")
str(Titanic)
Titanic<-Titanic[,-c(1,2)]
rules <- apriori(Titanic)
arules::inspect(rules)
rules.sorted <- sort(rules, by="lift")
arules::inspect(rules.sorted)

# rules with rhs containing "Survived" only
rules <- apriori(Titanic,parameter = list(minlen=1, supp=0.2, conf=0.5),appearance = list(rhs=c("Survived=No", "Survived=Yes"),default="lhs"),control = list(verbose=F))
arules::inspect(rules)
