# This Notebook is used for the Capstone Project in IBM Coursera Course.
# This Notebook will be mainly used for the capstone project
import pandas as pd
import numpy as np
print("Hello Capstone Project Course!")

