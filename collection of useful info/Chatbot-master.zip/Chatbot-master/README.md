# Chatbot

# Introducing Neomi My First ever chatbot.... still under development
<img src="https://github.com/neoaman/Chatbot/blob/master/static/img/AI.jpg" width="160" height="240"/>

Created a chatbot with voice output using tflearn,and flask.   
<h2> &#x1F535;  This chatbot has Voice output also, if your windows support speechsynthesis than it must work in your system </h2>
<hr>

## ☺ Recomended python 3.6.5  as python 3.7 and above might not support tflearn.
download it from link https://www.python.org/downloads/release/python-365/    
## ☺ Better if you create your own virtual Environment to run this program.

## ☺ Need to install the required packages in requirment.txt

```
> pip install -r requirements.txt
```

<hr>


## ☺ Its a web app, deployed using flask and some confusing java scripts.
## ☺ Used tflearn which is an older version and works with lower version of tensorflow, Tensorflow 2.0 and above are not supported
## ☺ Change the content inside the intent.json file for your desired output.
## ☺ Need to run the the run.py file and now you are good to go. 


```
> python run.py
```


Enjoy the app
