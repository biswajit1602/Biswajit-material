# discover-iot-sample

Sample application for connecting a smartphone to IBM IBM Watson IoT Platform.

(https://discover-iot.mybluemix.net)

[![Deploy to Bluemix](https://bluemix.net/deploy/button.png)](https://bluemix.net/deploy?repository=https://github.com/Blockchinnet/discover-iot-sample)
