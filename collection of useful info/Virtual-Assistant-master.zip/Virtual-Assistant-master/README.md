# Virtual-Assistant
Virtual Assistant. Its a simple python programming made by me after my post graduation.

# 1 Introduction:
This is a simple virtual assistant, which is going to do some interesting things for you, if you use it as instructed.
This is made for fun, not for serious use of dat manipulation. 

# 2 Instruction:
## 2.1- Check whather your python have the following packages in your computers or not 
PyAudio,pyttsx3,speech_recognition,wikipedia,webbrowser,pandas,matplotlib
install all these packages
## 2.2- If PyAudio is showing problem than
    Search for the directory where python is installed in your system and go to script folder within it
    e.g. : C:\Python3.7\Scripts
    Download the PyAudio from internet "PyAudio-0.2.11-cp37-cp37m-win32.whl" and paste it in the "script" directory
    open Powershell in the directory (shift + rightclick  and then "OpenPowershell Window here")
    write the code >> pip install PyAudio-0.2.11-cp37-cp37m-win32.whl
## 2.3- Paste the "va.py" file where you need to explore your data. 
    ( paste the va.py file in the folder containing the data sets in csv format)
## 2.4- Run the program using the cmd or powershell
    open Powershell in the directory (shift + rightclick  and then "OpenPowershell Window here") 
    write >> python vm.py
# 3 Voice commands
## 3.1 Explore Data
  If you want to explore data you need to say "look on data"
  Then you need to choose the data from the list shown to you.
  Now you are able to get: Information, head, tail of the data set along with some basic plotting tools (keyword is plot graph)
  > Plotting graph includes histogram, scatter plot, box plot
  
## 3.2 Wikipedia
  Say any name or theory you want to search in wikipedia.
  e.g. python in wikipedia
  must say wikipedia keyword with the search keyword so he could recognise to search it in wikipedia
## 3.3 Browser Opening
  I have just introduced two URL, you can add more
  e.g. Open Youtube, Open Google
## 3.4 Play Music
  If you want to try it, you need to change the directory path to the directory where your music is present. You need to work on it
## 3.5 Speak the time
  It will say you the correct time according to your computer.
  e.g. what is the time
> Most Important Kindly read the python codes carefully and try to understand, for exiting plot say "exit plot" and for exiting data say "exit data" finally exiting the program say "exit"

### I am here to listen for your problems, please comment, I will reply, as soon as possible
  
